<?php
    require("mpdf6/mpdf.php");
	
	$mpdf = new mPDF();
	$conexion = mysqli_connect("localhost","root","","sem20181");
	mysqli_set_charset($conexion, "utf8");
	$sql = "SELECT * FROM estudiantes";
	$res = mysqli_query($conexion, $sql);
	
	$estilos = "<style>*{font.family:'Verdana';}</style>";
	
	$html = $estilos;
	while($filas = mysqli_fetch_array($res,MYSQLI_BOTH)){
		$html = "<p style='background-color:#069; color:#FFF;'>$filas[0] - $filas[1]</p>";
		$mpdf -> WriteHTML($html);
		$mpdf->AddPage();
	}
	
    $mpdf -> Output();    
?>